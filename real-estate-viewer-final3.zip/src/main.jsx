import React from 'react';
import ReactDOM from 'react-dom/client';

const App = () => {
  return (
    <div style={{ padding: 20 }}>
      <h1>부동산 수익률 조회</h1>
      <p>여기에 실시간 부동산 매물 정보가 표시됩니다.</p>
    </div>
  );
};

ReactDOM.createRoot(document.getElementById('root')).render(<App />);